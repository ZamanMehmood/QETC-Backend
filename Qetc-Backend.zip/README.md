https://www.figma.com/file/CEnqGfLlMu0MkLXHunXCEU/Figma-to-React-Theme-1?node-id=0%3A1

https://drive.google.com/file/d/1dlDToyu6XeM8CWA6fCwfffmri7OqsYsn/view
